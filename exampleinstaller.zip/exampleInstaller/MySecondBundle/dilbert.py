__copyright__ = """
Copyright (c) David Brezina, 2008. All rights reserved.
Redistribution and use of the script is limited by the BSD licence (http://creativecommons.org/licenses/BSD/).
"""

fl.output = ""
print "********************"
print "Dilbert is the best!"
print "********************"